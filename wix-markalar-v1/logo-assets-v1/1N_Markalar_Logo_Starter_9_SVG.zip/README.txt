1N DIGITAL MEDIA | MARKALAR — SVG KAYNAK PAKETİ V1
Tarih: 25 Kasım 2026
Kapsam: 22 portföy kaydı; 9 doğrulanabilen marka SVG kaynağı.
Bu ZIP, 22 SVG'nin tamamını içerdiği iddiasını taşımaz. Eksik ve sürüm doğrulaması gereken kayıtları manifest.json'da gösterir.

KAYNAK VE HAKLAR
SVG dosyaları üçüncü taraf açık logo koleksiyonlarından değiştirilmeden alınmıştır. Logoların marka hakları ilgili sahiplerine aittir. Açık kaynak dosyanın varlığı logo kullanım izni veya doğrudan müşteri ilişkisi kanıtı değildir. Marka sahiplerinin güncel kurumsal kimliği ve portföy gösterimi izni kontrol edilmelidir.
- simple-icons/simple-icons: Turkish Airlines, Opel, Peugeot, Reebok, Schneider Electric, Renault, UPS
- glincker/thesvg: Mercedes-Benz yıldız amblemi; "Mercedes Ticari" özel varyantı için yeniden kontrol et
- murattahtaci/turkish-bank-logos-svg: iyzico

LUSION VİDEOSUNUN ANALİZİ
11,6 saniyelik referans kaydında siyah arka plan üzerinde üç yatay logo sırası, beyaz logotipler ve birbirinden bağımsız sürekli yatay kaydırma var. Kart, çerçeve, gölge ve gereksiz geometrik dekorasyon yok.
1N tasarımı: siyah #080A09, beyaz/grimsi logolar, küçük Barlow Condensed editoryal başlık, gerekirse #A8CF62 çok kontrollü vurgu. Üç satır birbirine zıt/dengeli yönlerde sürüklensin. Döngü bitiminde sıçrama olmasın. Masaüstü/tablet/mobilde hız ve logo aralığı uyarlansın.
Görünürlük dışındayken animasyonu durdurmak veya optimize etmek, prefers-reduced-motion durumunda animasyonsuz düzen, hover/focus durumunda duraklatma ve ekran okuyucuya tekrar eden logoların ikinci kopyasını gizleme zorunludur.
Proje adlarını logo sanmayın: "Opel Grandland X Trailer", "Peugeot 3008 Trailer", "Reebok Etkinlik Aftermovie", "Renault MAİS İzmir", "Jolly Tur Whitefest", "UPS World Run" ayrı iş/proje adlarıdır. Kayan logolar marka kimliğini; ayrı içerik alanı seçili işi temsil etsin.
Tüm 22 kaydın logo arşivi tamamlanıp onaylanmadan canlıda eksiksiz 22 logolu düzen olarak sunmayın.

BAŞVURU
Tam sıra, kaynak ve eksik kayıtlar için manifest.json.
